yarn install
mkdir dist
./node_modules/.bin/cowsay cow:RANDOMNESS_PLACEHOLDER > dist/index.txt
