module.exports = {
  generateBuildId() {
    return 'testing-build-id';
  },
};
