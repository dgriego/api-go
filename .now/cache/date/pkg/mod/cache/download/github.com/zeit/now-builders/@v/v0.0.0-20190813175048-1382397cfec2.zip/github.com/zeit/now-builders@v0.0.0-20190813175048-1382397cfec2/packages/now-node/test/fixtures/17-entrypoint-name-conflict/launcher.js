module.exports = (req, res) => {
  res.end('launcher:RANDOMNESS_PLACEHOLDER');
};
