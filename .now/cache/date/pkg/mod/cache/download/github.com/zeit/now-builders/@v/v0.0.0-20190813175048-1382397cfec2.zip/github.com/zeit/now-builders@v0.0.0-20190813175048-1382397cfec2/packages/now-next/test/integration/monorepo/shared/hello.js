module.exports = () => 'Hello!';
