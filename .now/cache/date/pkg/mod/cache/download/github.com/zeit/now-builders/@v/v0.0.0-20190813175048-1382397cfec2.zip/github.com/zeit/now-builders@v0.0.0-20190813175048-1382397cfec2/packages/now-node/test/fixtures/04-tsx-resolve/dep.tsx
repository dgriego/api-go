export default 'tsx';
