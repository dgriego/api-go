module.exports = async function () {
  return {};
};
