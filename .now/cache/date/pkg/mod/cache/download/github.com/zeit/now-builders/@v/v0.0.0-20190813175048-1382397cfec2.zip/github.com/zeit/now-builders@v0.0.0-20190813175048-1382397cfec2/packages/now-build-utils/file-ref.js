module.exports = require('./dist/index').FileRef;
