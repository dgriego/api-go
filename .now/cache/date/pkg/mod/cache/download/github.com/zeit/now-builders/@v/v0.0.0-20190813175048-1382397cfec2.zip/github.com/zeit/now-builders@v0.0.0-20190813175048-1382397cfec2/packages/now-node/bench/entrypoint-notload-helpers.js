module.exports = (req, res) => {
  res.end('hello');
};
