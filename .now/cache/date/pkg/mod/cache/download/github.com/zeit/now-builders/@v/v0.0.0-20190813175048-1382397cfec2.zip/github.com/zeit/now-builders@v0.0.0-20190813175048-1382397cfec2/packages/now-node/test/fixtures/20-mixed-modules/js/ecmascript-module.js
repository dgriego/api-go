export const dep1 = 'dep1';
export const another = 'another';
