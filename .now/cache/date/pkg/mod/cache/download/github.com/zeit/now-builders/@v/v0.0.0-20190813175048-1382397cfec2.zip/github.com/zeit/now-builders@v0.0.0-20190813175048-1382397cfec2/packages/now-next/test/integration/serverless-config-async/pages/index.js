export default () => 'Hello World!';
