Rails.application.routes.draw do
  root 'application#index'
end
