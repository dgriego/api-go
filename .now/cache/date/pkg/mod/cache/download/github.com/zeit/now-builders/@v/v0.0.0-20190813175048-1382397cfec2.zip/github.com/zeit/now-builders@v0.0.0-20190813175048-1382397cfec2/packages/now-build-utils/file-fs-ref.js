module.exports = require('./dist/index').FileFsRef;
