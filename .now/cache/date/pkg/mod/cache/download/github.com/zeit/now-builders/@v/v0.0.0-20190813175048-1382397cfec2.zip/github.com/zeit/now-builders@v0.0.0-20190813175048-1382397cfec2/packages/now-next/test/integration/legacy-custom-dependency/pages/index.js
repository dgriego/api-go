import fetch from 'isomorphic-unfetch';

// Fake fetch
fetch('https://example.com');

export default () => 'test';
