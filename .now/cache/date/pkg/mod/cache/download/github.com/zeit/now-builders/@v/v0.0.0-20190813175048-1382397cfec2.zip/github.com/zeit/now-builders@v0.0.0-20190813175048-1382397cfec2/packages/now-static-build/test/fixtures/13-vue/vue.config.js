module.exports = {
  // This is necessary for our test probes
  // so that the generated file names are deterministic.
  filenameHashing: false,
};
