module.exports = {
  target: 'serverless',
};
