module.exports = (req, res) => {
  res.end('helpers:RANDOMNESS_PLACEHOLDER');
};
