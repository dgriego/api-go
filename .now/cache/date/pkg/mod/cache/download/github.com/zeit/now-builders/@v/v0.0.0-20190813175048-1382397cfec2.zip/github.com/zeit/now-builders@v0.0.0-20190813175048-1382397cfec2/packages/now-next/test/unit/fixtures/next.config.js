module.exports = { target: 'serverless' };
