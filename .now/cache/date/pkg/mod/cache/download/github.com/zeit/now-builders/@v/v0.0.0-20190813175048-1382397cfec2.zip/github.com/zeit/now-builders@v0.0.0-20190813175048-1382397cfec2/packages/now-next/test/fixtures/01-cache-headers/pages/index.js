export default () => 'Hi';
