const F = () => 'Goodbye World!';
F.getInitialProps = async () => ({});
export default F;
