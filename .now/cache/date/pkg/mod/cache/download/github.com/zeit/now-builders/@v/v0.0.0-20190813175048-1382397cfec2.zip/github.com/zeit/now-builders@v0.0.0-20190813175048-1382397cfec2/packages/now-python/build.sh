ncc build src/index.ts -o dist
