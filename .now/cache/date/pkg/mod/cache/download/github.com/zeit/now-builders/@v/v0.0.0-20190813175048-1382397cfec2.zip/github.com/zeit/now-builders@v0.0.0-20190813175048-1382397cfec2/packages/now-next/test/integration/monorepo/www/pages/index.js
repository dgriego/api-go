import hello from '../../shared/hello';

export default () => `${hello()} Welcome to the index page`;
