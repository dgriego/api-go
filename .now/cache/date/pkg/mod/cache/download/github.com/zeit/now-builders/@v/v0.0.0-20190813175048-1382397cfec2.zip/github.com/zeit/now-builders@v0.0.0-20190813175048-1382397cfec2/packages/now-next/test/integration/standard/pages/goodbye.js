const F = () => 'Goodbye World!';
F.getInitialProps = () => ({});
export default F;
