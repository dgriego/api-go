module.exports = (req, res) => {
  res.end('bridge:RANDOMNESS_PLACEHOLDER');
};
