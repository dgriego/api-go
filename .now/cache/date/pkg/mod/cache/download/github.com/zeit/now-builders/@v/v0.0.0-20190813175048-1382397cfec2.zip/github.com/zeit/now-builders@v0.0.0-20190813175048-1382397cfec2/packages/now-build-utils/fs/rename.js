module.exports = require('../dist/index').rename;
