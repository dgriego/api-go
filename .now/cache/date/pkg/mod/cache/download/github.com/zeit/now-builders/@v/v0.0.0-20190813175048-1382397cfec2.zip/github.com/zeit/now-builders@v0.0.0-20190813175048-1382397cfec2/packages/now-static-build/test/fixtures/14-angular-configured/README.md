# Angular with a Node.js API

This example shows a [Angular](https://angular.io/) project (located in `package.json`) powered by a Node.js API.

In order to deploy, run:

```
now
```

When editing a file, you can run the following command to spawn a local development server:

```
now dev
```
