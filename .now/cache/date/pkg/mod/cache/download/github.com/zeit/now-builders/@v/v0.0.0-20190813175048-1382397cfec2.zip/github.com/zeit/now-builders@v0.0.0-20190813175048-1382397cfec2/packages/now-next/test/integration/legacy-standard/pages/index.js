export default () => 'Index page';
