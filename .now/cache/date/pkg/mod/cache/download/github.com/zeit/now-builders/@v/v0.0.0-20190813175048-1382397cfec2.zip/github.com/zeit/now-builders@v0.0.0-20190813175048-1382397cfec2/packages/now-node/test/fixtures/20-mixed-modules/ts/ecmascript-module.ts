export const dep1 = 'dep1';
