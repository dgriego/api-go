echo 'non-zero exit code should fail the build RANDOMNESS_PLACEHOLDER'
exit 1
