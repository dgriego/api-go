module.exports = (req, res) => {
  res.end('hello from api/index.js');
};
