ncc build index.ts -o dist
