module.exports = { dep2: 'dep2' };
