module.exports = (req, res) => {
  res.end(`RANDOMNESS_PLACEHOLDER:${process.versions.node}`);
};
