yarn install
mkdir dist
./node_modules/.bin/yodasay yoda:RANDOMNESS_PLACEHOLDER > dist/index.txt
