module.exports = new Promise(res => res({}));
